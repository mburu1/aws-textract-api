// __tests__/app.test.js
const request = require('supertest');
const app = require('../app');
const fs = require('fs');
const path = require('path');
const { TextractClient } = require('@aws-sdk/client-textract');

jest.mock('@aws-sdk/client-textract');

describe('AWS Textract API Tests', () => {
  
  beforeEach(() => {
    // Clear all mocks before each test
    jest.clearAllMocks();
  });

  test('Health endpoint returns 200', async () => {
    const response = await request(app).get('/health');
    expect(response.statusCode).toBe(200);
    expect(response.body).toHaveProperty('status', 'healthy');
  });

  test('Detect text endpoint returns 400 when no file is uploaded', async () => {
    const response = await request(app).post('/api/detect-text');
    expect(response.statusCode).toBe(400);
    expect(response.body).toHaveProperty('errors');
  });

  test('Detect text endpoint returns 200 with mock Textract response', async () => {
    // Mock implementation for TextractClient
    TextractClient.prototype.send = jest.fn().mockResolvedValue({
      DocumentMetadata: { Pages: 1 },
      Blocks: [
        {
          BlockType: 'LINE',
          Text: 'Sample detected text',
          Confidence: 99.5
        }
      ]
    });

    // Create a test file
    const testDir = path.join(__dirname, 'test-files');
    if (!fs.existsSync(testDir)) {
      fs.mkdirSync(testDir, { recursive: true });
    }
    const testFilePath = path.join(testDir, 'test-image.jpg');
    fs.writeFileSync(testFilePath, 'test image content');

    const response = await request(app)
      .post('/api/detect-text')
      .attach('document', testFilePath);

    expect(response.statusCode).toBe(200);
    expect(response.body).toHaveProperty('message', 'Document text detection successful');
    expect(response.body).toHaveProperty('result');
    expect(response.body.result).toHaveProperty('Blocks');

    // Clean up test file
    fs.unlinkSync(testFilePath);
    fs.rmdirSync(testDir);
  });

  test('Detect text endpoint handles Textract errors properly', async () => {
    // Mock implementation for TextractClient error
    TextractClient.prototype.send = jest.fn().mockRejectedValue(
      new Error('Textract service error')
    );

    // Create a test file
    const testDir = path.join(__dirname, 'test-files');
    if (!fs.existsSync(testDir)) {
      fs.mkdirSync(testDir, { recursive: true });
    }
    const testFilePath = path.join(testDir, 'test-image.jpg');
    fs.writeFileSync(testFilePath, 'test image content');

    const response = await request(app)
      .post('/api/detect-text')
      .attach('document', testFilePath);

    expect(response.statusCode).toBe(500);
    expect(response.body).toHaveProperty('message', 'Error detecting document text');

    // Clean up test file
    fs.unlinkSync(testFilePath);
    fs.rmdirSync(testDir);
  });
});